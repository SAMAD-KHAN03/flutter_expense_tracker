import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
import 'package:my_expenses/providers/auth_provider.dart';
class LoginScreen extends ConsumerWidget {
  final TextEditingController email = TextEditingController();
  final TextEditingController password = TextEditingController();

  LoginScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = ref.watch(authenticationProvider);
    final isLoading = auth.isLoading;
    return Scaffold(
      body: Stack(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            color: Theme.of(context).colorScheme.surfaceTint,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(
                  width: 100,
                  height: 100,
                  child: Image.asset(
                    'lib/assets/images/logo.png',
                    fit: BoxFit.contain,
                  ),
                ),
                const SizedBox(height: 10),
                TextFormField(
                  controller: email,
                  decoration: const InputDecoration(
                    icon: Icon(Icons.email),
                    border: OutlineInputBorder(),
                    hintText: 'Email id',
                    hintStyle: TextStyle(
                      color: Color.fromARGB(255, 174, 174, 174),
                    ),
                  ),
                ),
                const SizedBox(height: 5),
                TextFormField(
                  controller: password,
                  obscureText: true,
                  decoration: const InputDecoration(
                    icon: Icon(Icons.lock),
                    border: OutlineInputBorder(),
                    hintText: 'Password ',
                    hintStyle: TextStyle(
                      color: Color.fromARGB(255, 174, 174, 174),
                    ),
                  ),
                ),
                const SizedBox(height: 5),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    TextButton(
                      onPressed: () async {
                        await auth.signIn(email.text, password.text, context);
                      },
                      style: const ButtonStyle(
                        backgroundColor: WidgetStatePropertyAll(Colors.white),
                      ),
                      child: const Text('login'),
                    ),
                    const Text(
                      '/',
                      style: TextStyle(fontSize: 40, color: Colors.grey),
                    ),
                    TextButton(                      
                      onPressed: () async {
                        await auth.signUp(email.text, password.text, context);
                        // Handle successful sign-up if needed
                      },
                      style: const ButtonStyle(
                        backgroundColor: WidgetStatePropertyAll(Colors.white),
                      ),
                      child: const Text('signUp'),
                    ),
                    const Text(
                      '/',
                      style: TextStyle(fontSize: 40, color: Colors.grey),
                    ),
                    // const GoogleAuthScreen(),
                    IconButton(
                        onPressed: () async {
                          await auth.signInUsingGoogle(context);
                        },
                        icon: Icon(
                          MdiIcons.google,
                          color: Colors.white,
                        ))
                  ],
                ),
                if (isLoading)
                  const CircularProgressIndicator(
                    backgroundColor: Colors.white,
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
