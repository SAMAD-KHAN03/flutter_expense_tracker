import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:my_expenses/models/userprofile.dart';
import 'package:my_expenses/providers/auth_provider.dart';
import 'package:my_expenses/providers/expense_list_provider.dart';
import 'package:my_expenses/providers/profile_provider.dart';
import 'package:my_expenses/screens/add_expense_screen.dart';
import 'package:my_expenses/widgets/card_widget.dart';
import 'package:my_expenses/widgets/chart.dart';

class MainScreen extends ConsumerStatefulWidget {
  const MainScreen({super.key});

  @override
  ConsumerState<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends ConsumerState<MainScreen> {
  @override
  void initState() {
    super.initState();
    // Check if the user is authenticated and fetch data
    if (FirebaseAuth.instance.currentUser != null) {
      // Fetch data without storing the notifier reference
      ref.read(listprovider.notifier).fetchData();
    }
  }

  @override
  Widget build(BuildContext context) {
    var auth = ref.watch(authenticationProvider);
    ref.watch(listprovider);
    final profile = ref.watch(userprofileprovider);
    bool isfetching = ref.watch(listprovider.notifier).isFetching;
    double totalAmount =
        ref.watch(listprovider.notifier).categorySum.values.fold(
              0.0,
              (sum, v) => sum + v,
            );

    return Scaffold(
      appBar: AppBar(
        actions: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 8, 8, 8),
            child: InkWell(
              onTap: () async {
                await auth.signOut();
              },
              child: auth.isSignout
                  ? const CircularProgressIndicator()
                  : Chip(
                      label: const Text('Sign out'),
                      elevation: 20,
                      avatar: const Icon(Icons.logout_outlined),
                      shadowColor: Colors.black,
                      backgroundColor:
                          Theme.of(context).colorScheme.inversePrimary,
                      padding: const EdgeInsets.all(8.0),
                    ),
            ),
          ),
        ],
        title: const Text('Expenses'),
        leading: Container(
            padding: EdgeInsets.fromLTRB(8, 4, 4, 4),
            height: 40,
            width: 40,
            child: CircleAvatar(
              radius: 20,
              backgroundImage: NetworkImage(profile.profilepic),
            )),
        centerTitle: false,
      ),
      floatingActionButton: FloatingActionButton(
        focusElevation: 2.0,
        onPressed: () {
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (context) => const AddExpenseScreen(),
            ),
          );
        },
        child: const Icon(Icons.add),
      ),
      body: isfetching
          ? Center(
              child: CircularProgressIndicator(),
            )
          : SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    height: 25,
                    width: double.infinity,
                    padding: const EdgeInsets.fromLTRB(16, 8, 0, 0),
                    child: Text(
                      "Total Amount Spent: ${totalAmount.toStringAsFixed(2)} Rs",
                    ),
                  ),
                  const Chart(), // Ensure Chart widget is included for visualization
                  const CardWidget(),
                ],
              ),
            ),
    );
  }
}
