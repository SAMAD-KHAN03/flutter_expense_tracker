import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:my_expenses/models/userprofile.dart';

class UserProfileProvider extends StateNotifier<UserProfile> {
  UserProfileProvider() : super(UserProfile());
  Future<void> fetchUserProfile() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .get();
      if (userDoc.exists) {
        final data = userDoc.data()!;
        state =
            UserProfile(email: data['email'], profilepic: data['profilepic']);
      }
    }
  }
}

final userprofileprovider =
    StateNotifierProvider<UserProfileProvider, UserProfile>((ref) {
  return UserProfileProvider();
});
