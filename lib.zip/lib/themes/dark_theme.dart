import 'package:flutter/material.dart';

var kdarkColorScheme = ColorScheme.fromSeed(
    seedColor: const Color.fromARGB(255, 5, 99, 125),
    brightness: Brightness.dark);
ThemeData darkthemedata = ThemeData(
  primaryTextTheme:
      const TextTheme(bodyMedium: TextStyle(color: Colors.blueGrey)),
  colorScheme: kdarkColorScheme,
  cardTheme: const CardTheme().copyWith(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      color: Colors.white),
  elevatedButtonTheme: ElevatedButtonThemeData(
      style: const ButtonStyle().copyWith(
          backgroundColor:
              WidgetStatePropertyAll(kdarkColorScheme.primaryContainer))),
  textTheme: ThemeData.dark().textTheme, // Use dark theme text styles
);
