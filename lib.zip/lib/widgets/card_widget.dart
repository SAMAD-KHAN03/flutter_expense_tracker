import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:my_expenses/models/expense.dart';
import 'package:my_expenses/providers/expense_list_provider.dart';

class CardWidget extends ConsumerWidget {
  const CardWidget({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final expenselist = ref.watch(listprovider);
    return Column(
      children: [
        for (var expense in expenselist)
          Card(
            color: Theme.of(context).cardTheme.color,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  Icon(categoryIcons[expense.categ]),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          expense.title,
                          style: const TextStyle(fontSize: 18),
                        ),
                        Text(expense.categ.toString())
                      ],
                    ),
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            const Icon(
                              Icons.currency_rupee,
                              size: 16,
                            ),
                            Text(
                              expense.price.toString(),
                            ),
                          ],
                        ),
                        Text(expense.formattedDate),
                        Text(expense.time),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          )
      ],
    );
  }
}
