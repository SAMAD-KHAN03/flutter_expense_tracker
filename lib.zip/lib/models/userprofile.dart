class UserProfile {
  final String email;
  final String profilepic;
  UserProfile({this.email = '', this.profilepic = ''});
}
