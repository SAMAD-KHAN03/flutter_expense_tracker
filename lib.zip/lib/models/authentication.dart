import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:image_picker/image_picker.dart';

class Authentication extends ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  bool _isLoading = false;
  bool _isSignout = false;

  bool get isLoading => _isLoading;
  bool get isSignout => _isSignout;

  Stream<User?> get stateChange => _auth.authStateChanges();

  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }

  void _setSignout(bool value) {
    _isSignout = value;
    notifyListeners();
  }

  Future<void> signIn(String email, String password, BuildContext context) async {
    _setLoading(true);
    try {
      await _auth.signInWithEmailAndPassword(email: email, password: password);
    } on FirebaseAuthException catch (e) {
      await showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Error'),
          content: Text(e.toString()),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('OK'),
            ),
          ],
        ),
      );
    } finally {
      _setLoading(false);
    }
  }

  Future<bool> signUp(String email, String password, BuildContext context) async {
    _setLoading(true);
    try {
      final userCredential = await _auth.createUserWithEmailAndPassword(
          email: email, password: password);
      String profilePicUrl = await uploadProfilePic();
      await FirebaseFirestore.instance
          .collection('users')
          .doc(userCredential.user?.uid)
          .set({
        'email': email,
        'profilePicUrl': profilePicUrl, 
      });
      return true;
    } on FirebaseAuthException catch (e) {
      String errorMessage = 'Something went wrong';
      if (e.code == 'email-already-in-use') {
        errorMessage = 'This Email is already in use';
      } else if (e.code == 'invalid-email') {
        errorMessage = 'Invalid Email';
      }
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(errorMessage)));
    } finally {
      _setLoading(false);
    }
    return false;
  }

  Future<String> uploadProfilePic() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      final storageRef = FirebaseStorage.instance.ref();
      final imageRef = storageRef.child('profilepic/${pickedFile.name}');
      await imageRef.putFile(File(pickedFile.path));
      return await imageRef.getDownloadURL();
    }
    throw Exception('No image selected');
  }

  Future<void> signOut() async {
    _setSignout(true);
    await _auth.signOut();
    await GoogleSignIn().signOut();
    _setSignout(false);
  }

  Future<dynamic> signInUsingGoogle(BuildContext context) async {
    _setLoading(true);
    try {
      final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();
      final GoogleSignInAuthentication? googleAuth =
          await googleUser?.authentication;
      final credentials = GoogleAuthProvider.credential(
          accessToken: googleAuth?.accessToken, idToken: googleAuth?.idToken);
      return await _auth.signInWithCredential(credentials);
    } on Exception catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      _setLoading(false);
    }
  }
}